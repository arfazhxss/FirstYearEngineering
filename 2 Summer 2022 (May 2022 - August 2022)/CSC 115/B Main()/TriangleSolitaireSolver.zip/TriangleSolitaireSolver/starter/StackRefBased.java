// see Stack Interface for documentation
// complete the given stubs
public class StackRefBased<T extends Object> implements Stack<T> {
    private StackNode<T> top;

    public StackRefBased() {
        this.top = null;
    }

    public int size() {


        return 0;
    }


    public boolean isEmpty() {
        return true;
    }


    public void push(T data) {

    }


    public T pop() throws StackEmptyException {
        return null;
    }


    public T peek() throws StackEmptyException {
        return null;
    }


    public void makeEmpty() {

    }

    /*
     * Purpose: creates and returns a String representation of this Stack
     *  from bottom to top
     * Parameters: none
     * Returns: String - the representation
     */
    public String toString() {
        String result = "";

        StackNode<T> tmp = top;
        while(tmp != null) {
            result = tmp.getValue() + result;
            tmp = tmp.getNext();
        }

        return result;
    }
    /*
     * Purpose: overrides Object's equals method
     *  determines whether this StackRefBased has the same
     *  elements as other StackRefBased, in the same order
     * Parameters: Object other - the other StackRefBased
     * Precondition: assumes other is an instance of StackRefBased<T>
     * Returns: boolean - true if the are equal, false otherwise
     */
    public boolean equals(Object other) {
        // this line will cause a warning when you compile
        // you can ignore this warning
        StackRefBased<T> otherStack = (StackRefBased<T>)other;

        StackNode<T> thisTmp = top;
        StackNode<T> otherTmp = otherStack.top;

        while(thisTmp!=null && otherTmp!=null){
            T thisVal = thisTmp.getValue();
            T otherVal = otherTmp.getValue();
            if (!thisVal.equals(otherVal)){
                return false;
            }
            thisTmp = thisTmp.getNext();
            otherTmp = otherTmp.getNext();
        }

        if (thisTmp!=null || otherTmp!=null)
            return false;
        else
            return true;
    }
}
